#! /bin/bash
go build -o .\bin\client .\src\main.go .\src\simplestrategy.go